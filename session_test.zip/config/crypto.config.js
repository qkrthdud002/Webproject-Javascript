module.exports={
    count:214356,
    length:128,
    digest:'sha512'
};